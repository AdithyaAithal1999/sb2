package com.dailycodebuffer.springaopdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAopDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
