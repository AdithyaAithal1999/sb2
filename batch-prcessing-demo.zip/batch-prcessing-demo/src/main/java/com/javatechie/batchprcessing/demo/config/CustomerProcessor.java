package com.javatechie.batchprcessing.demo.config;


import org.springframework.batch.item.ItemProcessor;

import com.javatechie.batchprcessing.demo.entity.Customer;

public class CustomerProcessor implements ItemProcessor<Customer,Customer> {
	public Customer process(Customer customer) {
		if(customer.getCountry().equals("United States")) {
			return customer;
		}
		else {
			return null;
		}
	}
}
