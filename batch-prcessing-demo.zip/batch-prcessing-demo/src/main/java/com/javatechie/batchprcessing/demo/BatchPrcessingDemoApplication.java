package com.javatechie.batchprcessing.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatchPrcessingDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchPrcessingDemoApplication.class, args);
	}

}
