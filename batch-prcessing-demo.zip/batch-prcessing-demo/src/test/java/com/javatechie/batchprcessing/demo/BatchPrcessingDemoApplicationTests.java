package com.javatechie.batchprcessing.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchPrcessingDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
