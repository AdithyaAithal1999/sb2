package com.dailycodebuffer.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.dailycodebuffer.user.VO.Department;
import com.dailycodebuffer.user.VO.ResponseTemplateVO;
import com.dailycodebuffer.user.entity.User;
import com.dailycodebuffer.user.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RestTemplate restTemplate;
	
	public User saveUser(User user) {
		return userRepository.save(user);
	}
	
	public ResponseTemplateVO fetchUserDetails(Long userId) {
		User user=userRepository.findById(userId).get();

		ResponseTemplateVO vo=new ResponseTemplateVO();
		
//		Department department=restTemplate.getForObject("http://localhost:9001/departments/"+user.getDepartmentId(), Department.class);
		
		Department department=restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/"+user.getDepartmentId(), Department.class);
		
		vo.setDepartment(department);
		vo.setUser(user);
		
		return vo;
	}

}
