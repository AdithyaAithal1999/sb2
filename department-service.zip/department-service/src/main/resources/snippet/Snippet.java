package snippet;

public class Snippet {
	public static void main(String[] args) {
		spring:
		  cloud:
		    config:
		      enabled: true
		      uri: http://localhost:9296
	}
}

