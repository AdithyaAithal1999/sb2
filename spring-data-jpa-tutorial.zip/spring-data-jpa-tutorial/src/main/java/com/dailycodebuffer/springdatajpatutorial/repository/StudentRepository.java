package com.dailycodebuffer.springdatajpatutorial.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dailycodebuffer.springdatajpatutorial.entity.Student;

//https://docs.spring.io/spring-data/jpa/docs/2.5.1/reference/html/#jpa.query-methods


@Repository
public interface StudentRepository extends JpaRepository<Student, Long>{
	
	public List<Student> findByFirstName(String firstName);
	
	public List<Student> findByFirstNameContaining(String name);
	
	public List<Student> findByLastNameNotNull();
	
	public List<Student> findByGuardianName(String guardianName);
	
	@Query("select s from Student as s where s.emailId = ?1")
	public Student findByEmailAddress(String emailId);
	
	@Query("select s.firstName from Student as s where s.emailId=?1")
	public String findByEmailAddressFirstName(String emailId);
	
	@Query(
			value="select * from tbl_student as s where s.email_address=?1",
			nativeQuery=true
			)
	public Student findByEmailAddressNativequery(String emailId);
	
	@Modifying
	@Transactional
	@Query(
			value="update tbl_student set first_name=?1 where email_address=?2",
			nativeQuery=true
			)
	int updateStudentNameByEmailId(String firstName, String emailId);

}
