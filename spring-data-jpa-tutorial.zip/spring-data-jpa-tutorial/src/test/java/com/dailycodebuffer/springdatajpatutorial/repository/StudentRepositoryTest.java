package com.dailycodebuffer.springdatajpatutorial.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dailycodebuffer.springdatajpatutorial.entity.Guardian;
import com.dailycodebuffer.springdatajpatutorial.entity.Student;

@SpringBootTest
class StudentRepositoryTest {

	@Autowired
	StudentRepository studentRepository;

	@Test
	public void saveStudent() {
		Student student=Student.builder() 
				.firstName("Shabbir")
				.lastName("Dawoodi")
				.emailId("shabbir.dawoodi@gmail.com")
//				.guardianName("Nikhil")
//				.guardianEmailId("nikhil@gmail.com")
//				.guardianMobile("9999999999")
				.build();
		
		studentRepository.save(student);
	}
	
	@Test
	public void saveDepartmentWithGuardian() {
		Guardian guardian=Guardian.builder()
				.name("Nikhil")
				.email("nikhil@gmail.com")
				.mobile("9999999999")
				.build();
		
		Student student=Student.builder() 
				.firstName("Shabbir")
				.lastName("H")
				.emailId("shabbir@gmail.com")
				.guardian(guardian)
				.build();
		
		studentRepository.save(student);
	}
	
	@Test
	public void fetchStudentByStudentFirstName() {
		List<Student> list=studentRepository.findByFirstName("Shabbir");
		System.out.println("Student Details based on first name = "+list);
	}
	
	@Test
	public void fetchByStudentNameWithGivenCharacters() {
		List<Student> list=studentRepository.findByFirstNameContaining("Sha");
		System.out.println("Student details with first name for given characters : "+list);
	}
	
	@Test
	public void fetchStudentsBasedOnGuardianName() {
		List<Student> list=studentRepository.findByGuardianName("Nikhil");
		System.out.println("Student details based on the guardian name Nikhil ="+list);
	}
	
	@Test
	public void fetchStudentDetailsBasedOnEmailQuery() {
		Student student=studentRepository.findByEmailAddress("shabbir@gmail.com");
		System.out.println("The student details based on email address using query = "+student);
	}
	
	@Test
	public void fetchStudentFirstNameByEmailUsingQuery() {
		String firstName=studentRepository.findByEmailAddressFirstName("shabbir@gmail.com");
		System.out.println("Student first name based on email using query = "+firstName);
	}
	
	@Test
	public void fetchStudentDetailsBaseedonEmailUsingNativeQuery() {
		Student student=studentRepository.findByEmailAddressNativequery("shabbir@gmail.com");
		System.err.println("Student deails based on email address using native query="+student);
	}
	
	@Test
	public void  updateStudentNameByEmailIdTest() {
		int num=studentRepository.updateStudentNameByEmailId("shabbir dawoodi", "shabbir@gmail.com");
		System.out.println("Updated fist name= "+num);
	}

}
