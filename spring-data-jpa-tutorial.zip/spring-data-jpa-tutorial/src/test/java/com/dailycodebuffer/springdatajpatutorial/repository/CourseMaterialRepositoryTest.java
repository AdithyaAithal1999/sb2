package com.dailycodebuffer.springdatajpatutorial.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dailycodebuffer.springdatajpatutorial.entity.Course;
import com.dailycodebuffer.springdatajpatutorial.entity.CourseMaterial;

@SpringBootTest
class CourseMaterialRepositoryTest {

	@Autowired
	private CourseMaterialRepository courseMaterialRepository;

	@Test
	public void saveCourseMaterial() {
		Course course=Course.builder().title(".net")
				.credit(6)
				.build();
				
		
		CourseMaterial courseMaterial=
				CourseMaterial.builder()
				.url("www.dailycodebufferdata.com")
				.course(course)
				.build();
				
		courseMaterialRepository.save(courseMaterial);
	}
	
	@Test
	public void fetchCourseMaterialDetailsLazy() {
		List<CourseMaterial> list=courseMaterialRepository.findAll();
		System.out.println("courseMaterial details = "+list);
	}

}
