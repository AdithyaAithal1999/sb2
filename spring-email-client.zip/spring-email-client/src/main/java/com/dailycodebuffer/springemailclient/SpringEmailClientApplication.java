package com.dailycodebuffer.springemailclient;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class SpringEmailClientApplication {
	@Autowired
	private EmailSenderService service;
	

	public static void main(String[] args) {
		SpringApplication.run(SpringEmailClientApplication.class, args);
	}

//	@EventListener(ApplicationReadyEvent.class)
//	public void triggerMail() throws MessagingException{
//		service.sendSimpleEmail("adithyaaaithal1999@gmail.com",
//				"This is body", "This is subject");
//	}
	
	@EventListener(ApplicationReadyEvent.class)
	public void triggerMail() throws MessagingException{
		service.sendEmailWithAttachment("adithyaaaithal1999@gmail.com",
				"This is email body with attachment...",
				"This email has attachment...",
				"C:\\Users\\hp\\Pictures\\IMG_20200627_214820.jpg");
	}
}
