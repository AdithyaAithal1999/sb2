package com.dailycodebuffer.springboottutorial.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dailycodebuffer.springboottutorial.entity.Department;
import com.dailycodebuffer.springboottutorial.error.DepartmentNotFoundException;
import com.dailycodebuffer.springboottutorial.service.DepartmentService;

@RestController
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
	
	public final Logger LOGGER=LoggerFactory.getLogger(DepartmentController.class);
	
	@Value("${welcome.message}")
	//@Value("${welcome.message:Welcome to DailyCodeBuffer}") -> default value if value not present in application.properties
	private String welcomeMessage;
	
	@GetMapping("/")
	public String getWelcome() {
		return welcomeMessage;
	}
	
	//@Valid to add hibernate validation from Department entity
	@PostMapping("/departments/save")
	public Department saveDepartment(@Valid@RequestBody Department department) {
		LOGGER.info("saving department");
		return departmentService.saveDepartment(department);
	}
	
	@GetMapping("/departments")
	public List<Department> fetchDepartmentList(){
		return departmentService.fetchDepartmentList();
	}
	
	@GetMapping("/departments/{id}")
	public Department fetchDepartment(@PathVariable("id") Long departmentId) throws DepartmentNotFoundException {
		return departmentService.fetchDepartment(departmentId);
	}
	
	@DeleteMapping("/departments/{id}")
	public String deleteDepartment(@PathVariable("id") Long departmentId) {
		return departmentService.deleteDepartment(departmentId);
	}
	
	@PutMapping("/departments/update/{id}")
	public Department updateDepartment(@PathVariable("id") Long departmentId, @RequestBody Department department) {
		return departmentService.updateDepartment(departmentId, department);
	}
	
	@GetMapping("/departments/name/{departmentName}")
	public Department getDepartmentByName(@PathVariable("departmentName") String departmentName) {
		return departmentService.fetchDepartmentByName(departmentName);
	}
	
	

}
