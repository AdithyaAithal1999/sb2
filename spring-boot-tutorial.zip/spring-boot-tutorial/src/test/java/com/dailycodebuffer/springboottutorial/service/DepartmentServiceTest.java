package com.dailycodebuffer.springboottutorial.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.dailycodebuffer.springboottutorial.entity.Department;
import com.dailycodebuffer.springboottutorial.repository.DepartmentRepository;

@SpringBootTest
class DepartmentServiceTest {
	
	@Autowired
	private DepartmentService departmentService;
	
	@MockBean
	DepartmentRepository departmentRepository;
	
	@BeforeEach
	void setup() {
		Department department=Department.builder(). 
				departmentName("IT").
				departmentAddress("Ahmedabad").
				departmentCode("IT"). 
				departmentId(1L).build();
		Mockito.when(departmentRepository.findByDepartmentNameIgnoreCase("IT")).thenReturn(department);
		
	}

	

	@Test
	@DisplayName("Det Data based on validating department name")
	void validFetchDepartmentName() {
		String departmentName="IT";
		
		Department found=departmentService.fetchDepartmentByName(departmentName);
		assertEquals(departmentName, found.getDepartmentName());
		
		//assertEquals("Ahmedabad", found.getDepartmentAddress());
		
	}

}
