package com.dailycodebuffer.bankmanagementsystem.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dailycodebuffer.bankmanagementsystem.entity.Account;
import com.dailycodebuffer.bankmanagementsystem.service.BankService;

@RestController
public class BankController {
	
	@Autowired
	private BankService bankService;
	
	@GetMapping("/healthCheck")
	private String healthWatch() {
		return "HealthWatch is fine";
	}
	
	@PostMapping("/save")
	public Account saveAccount(@RequestBody Account account) {
		return bankService.saveAccount(account);
	}
	
	@GetMapping("/accountDetail/{id}")
	public Account fetchAccountDetailsBasedOnId(@PathVariable("id") Long accountId) {
		return bankService.fetchAccountDetailsBasedOnId(accountId);
	}
	
	@GetMapping("/accountDetails")
	public List<Account> fetchAllAccounts(){
		return bankService.fetchAllAccounts();
	}
	
	@GetMapping("/accountDetailsDate/{date}")
	public List<Account> fetchAccountBasedOnDate(@PathVariable String date){
		LocalDate d=LocalDate.parse(date);
		return bankService.fetchAccountBasedOnDate(d);
	}
	
	@GetMapping("/accountDetailsBalance/{id}")
	public int fetchBalanceOfAccount(@PathVariable("id") Long accountId) {
		return bankService.fetchBalanceOfAccount(accountId);
	}

}
