package com.dailycodebuffer.bankmanagementsystem.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dailycodebuffer.bankmanagementsystem.entity.Account;

@Repository
public interface BankRepository extends JpaRepository<Account, Long>{
	public List<Account> findByDate(LocalDate date);
	
	//public int findByBalance(Long accountId);

}
