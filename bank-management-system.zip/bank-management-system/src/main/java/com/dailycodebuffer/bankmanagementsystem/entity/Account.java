package com.dailycodebuffer.bankmanagementsystem.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.sun.istack.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(
		name="ACCOUNT",
		uniqueConstraints=@UniqueConstraint(
				name="unique_account",
				columnNames="personName"
				)
		)
public class Account {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long accountId;
	
	@Column(
			name="personName",
			nullable=false
			)
	private String personName;
	private int balance;
	private LocalDate date;
	
	@NotNull
	private String panNumber;
	private String address;
	
	

}
