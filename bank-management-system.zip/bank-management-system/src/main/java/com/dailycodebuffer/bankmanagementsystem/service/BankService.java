package com.dailycodebuffer.bankmanagementsystem.service;

import java.time.LocalDate;
import java.util.List;

import com.dailycodebuffer.bankmanagementsystem.entity.Account;

public interface BankService {
	public Account saveAccount(Account account);

	public Account fetchAccountDetailsBasedOnId(Long accountId);

	public List<Account> fetchAllAccounts();

	public List<Account> fetchAccountBasedOnDate(LocalDate date);

	public int fetchBalanceOfAccount(Long accountId);

}
