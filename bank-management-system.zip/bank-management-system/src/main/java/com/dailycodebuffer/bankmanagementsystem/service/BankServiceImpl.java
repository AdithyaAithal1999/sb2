package com.dailycodebuffer.bankmanagementsystem.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dailycodebuffer.bankmanagementsystem.entity.Account;
import com.dailycodebuffer.bankmanagementsystem.repository.BankRepository;

@Service
public class BankServiceImpl implements BankService{
	
	@Autowired
	private BankRepository bankRepository;
	
	public Account saveAccount(Account account) {
		return bankRepository.save(account);
	}

	@Override
	public Account fetchAccountDetailsBasedOnId(Long accountId) {
		// TODO Auto-generated method stub
		return bankRepository.findById(accountId).get();
	}

	@Override
	public List<Account> fetchAllAccounts() {
		// TODO Auto-generated method stub
		return bankRepository.findAll();
	}

	@Override
	public List<Account> fetchAccountBasedOnDate(LocalDate date) {
		// TODO Auto-generated method stub
		return bankRepository.findByDate(date);
	}

	@Override
	public int fetchBalanceOfAccount(Long accountId) {
		// TODO Auto-generated method stub
		Account account=bankRepository.findById(accountId).get();
		return account.getBalance();
	}

}
