package com.dailycodebuffer.SpringFrameworkDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFrameworkDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFrameworkDemoApplication.class, args);
	}

}
