package demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		
		ApplicationContext context=new AnnotationConfigApplicationContext(BeanConfig.class);
		Doctor doctor=context.getBean(Doctor.class); 
		doctor.assist();
//		doctor.setQualification("MBBS");
//		System.out.println(doctor);
		
//		Doctor doctor1=context.getBean(Doctor.class); 
//		System.out.println(doctor1);
		
		//Nurse nurse=context.getBean(Nurse.class);
//		Nurse nurse=(Nurse)context.getBean("nurse");
//		nurse.assist();
		
//		Staff staff=context.getBean(Doctor.class);
//		staff.assist();
		
		//System.out.println("Qualification is : ");

	}

}
