package demo;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.stereotype.Component;

//@Component
public class Doctor implements Staff, BeanNameAware{
	public String qualification;
//	public Doctor(String qualification) {
//		super();
//		this.qualification = qualification;
//	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification=qualification;
	}
	public void assist() {
		System.out.println("Doctor is assisting.");
	}
	public String toString() {
		return getQualification();
	}
	
	@Override
	public void setBeanName(String name){
		System.out.println("setBeanName() method is called.");
	}
	
	@PostConstruct
	public void postConstruct() {
		System.out.println("Post construct method is called.");
	}

}
