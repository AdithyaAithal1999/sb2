package demo;

import org.springframework.stereotype.Component;

@Component
public class Hotel {
	public void welcom() {
		System.out.println("Welcome to our hotel");
	}

}
