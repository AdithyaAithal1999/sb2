package demo;

import java.util.Arrays;

import org.springframework.stereotype.Component;

@Component
public class Menu {
	String[] str= {"Idli","Vada","Buns","Pulav","Chapathi"};
	public void menu() {
		System.out.println("Menu contains : " +Arrays.toString(str));
	}

}
