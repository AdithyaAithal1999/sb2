package com.dailycodebuffer.springaopdemopractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAopDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringAopDemo1Application.class, args);
	}

}
