package com.dailycodebuffer.springaopdemopractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAopDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
