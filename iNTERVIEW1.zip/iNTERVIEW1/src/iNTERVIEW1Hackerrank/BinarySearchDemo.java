package iNTERVIEW1Hackerrank;

public class BinarySearchDemo{
public static void main(String[] args){
String S="abba";

StringBuffer res=new StringBuffer(S);
StringBuffer sb=new StringBuffer(S);
System.out.println(sb);
sb.reverse();
System.out.println(sb);

System.out.println(res.equals(sb));

}


}
