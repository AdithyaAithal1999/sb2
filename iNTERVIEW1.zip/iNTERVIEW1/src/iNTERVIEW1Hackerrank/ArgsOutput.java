package iNTERVIEW1Hackerrank;

public class ArgsOutput {
	public static void main(String[] args) {
		int[] arr=new int[5];
		System.out.println("Hello");
	}

}
