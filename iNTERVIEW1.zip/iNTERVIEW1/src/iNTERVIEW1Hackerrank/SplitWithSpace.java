package iNTERVIEW1Hackerrank;

import java.util.Arrays;

public class SplitWithSpace {
	public static void main(String[] args) {
		String string = "The best of both worlds"; 
		String[] sarr=string.split("\s");
		for(String s: sarr) {
			System.out.println(s);
		}
	}

}
