package iNTERVIEW1Hackerrank;

public class NoOfCharacters {
	public static void main(String[] args) {
		String string = "The best of both worlds"; 
		int n=noOfCharacters(string);
		System.out.println(n);
	}
// count each characters except string
//	private static int noOfCharacters(String string) {
//		// TODO Auto-generated method stub
//		int count=0;
//		for(int i=0;i<string.length();i++) {
//			if(string.charAt(i)==' ') {
//				continue;
//			}else {
//				count++;
//			}
//		}
//		return count;
//	}
	
	private static int noOfCharacters(String string) {
		char[] carr=string.toCharArray();
		int count=0;
		for(char ch:carr) {
			if(ch==' ') {
				continue;
			}else {
				count++;
			}
		}
		return count;
	}

}
